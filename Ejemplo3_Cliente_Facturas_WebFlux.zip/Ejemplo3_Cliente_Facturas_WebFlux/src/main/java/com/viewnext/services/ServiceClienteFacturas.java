package com.viewnext.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.viewnext.models.Factura;

import reactor.core.publisher.Flux;

@Service
public class ServiceClienteFacturas {
	
	// Flux -> Similar a una Lista solo que trabaja con streams
	public Flux<Factura> getAll(){
		
		// Cliente para lanzar la peticion
		WebClient cliente = WebClient.create("http://localhost:8081/facturas");
		
		 // Crear 4 streams -> 4 Publisher emiten el flujo de datos
		Flux<Factura> facturas = cliente.get().retrieve().bodyToFlux(Factura.class);
		Flux<Factura> facturas2 = cliente.get().retrieve().bodyToFlux(Factura.class);
		Flux<Factura> facturas3 = cliente.get().retrieve().bodyToFlux(Factura.class);
		Flux<Factura> facturas4 = cliente.get().retrieve().bodyToFlux(Factura.class);
		
		// Unir los 4 Flux en 1 solo
		Flux<Factura> todas = Flux.merge(facturas, facturas2, facturas3, facturas4);
		return todas;
	}

}
