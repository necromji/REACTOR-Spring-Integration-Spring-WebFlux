package es.indra;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class NumerosTest{
	
	@BeforeClass
	public void inicioClase() {
		// Cargar un recurso al inicio
	}
	
	@AfterClass
	public void finalClase() {
		// Liberar ese recurso
	}
	
	@Before // Una vez por cada test
	public void inicioTest() {
		System.out.println("Inicio prueba unitaria");
	}
	
	@After // Una vez por cada test
	public void finTest() {
		System.out.println("Fin prueba unitaria");
	}
	
	@Test // Uno por metodo
	public void esPositivoTest() {
		System.out.println("Ejecutando prueba unitaria");
		
		// Crear una instancia de la clase real
		Numeros instance = new Numeros();
		
		// Genero el resultado esperado
		boolean esperado = true;
		
		// Hago la peticion y recojo el valor real
		boolean real = instance.esPositivo(7);
		
		// Evaluo el resultado
		Assert.assertEquals(esperado, real);
		
		
	}
	

}
