package es.indra;

public class Numeros {
	
	// El metodo tiene que retornar algo para poder ejecutar la prueba unitaria
	public boolean esPositivo(int num) {
		if (num >= 0 ) {
			return true;
		} else {
			return false;
		}
	}

}
