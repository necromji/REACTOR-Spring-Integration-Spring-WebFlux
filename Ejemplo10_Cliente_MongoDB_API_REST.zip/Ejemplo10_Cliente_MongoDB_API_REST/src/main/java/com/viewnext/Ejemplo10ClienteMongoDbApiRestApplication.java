package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.viewnext.services.Cliente_RestTemplate;
import com.viewnext.services.Cliente_WebClient;

@SpringBootApplication
public class Ejemplo10ClienteMongoDbApiRestApplication implements CommandLineRunner{
	
	@Autowired
	private Cliente_RestTemplate service;
	
	@Autowired
	private Cliente_WebClient webClientService;


	public static void main(String[] args) {
		SpringApplication.run(Ejemplo10ClienteMongoDbApiRestApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Peticion con RestTemplate --------------------------");
		// Lanzo peticion y muestro resultados
		service.peticion1().forEach(System.out::println);
		System.out.println("-----------------------------------");
		
		System.out.println("Peticion con WebClient --------------------------");
		webClientService.peticion2()
			.subscribe(p -> {
				System.out.println(p);
			});
		
	}

}
