package com.viewnext.services;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.viewnext.documents.Producto;

import reactor.core.publisher.Flux;

@Service
public class Cliente_WebClient {
	
	public Flux<Producto> peticion2(){
		// Cliente para lanzar la peticion
		WebClient cliente = WebClient.create("http://localhost:9090/api/productos");
		return cliente.get().retrieve().bodyToFlux(Producto.class);
	}

}
