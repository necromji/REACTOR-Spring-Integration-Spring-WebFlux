package com.viewnext.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.viewnext.documents.Producto;

@Service
public class Cliente_RestTemplate {
	
	public List<Producto> peticion1(){
		RestTemplate template = new RestTemplate();
		return Arrays.asList(template.getForObject("http://localhost:9090/api/productos", Producto[].class));
	}
}
