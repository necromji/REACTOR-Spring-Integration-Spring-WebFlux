package com.viewnext;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo7ProgramacionReactivaApplication implements CommandLineRunner {

	private static Logger log = LoggerFactory.getLogger(Ejemplo7ProgramacionReactivaApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo7ProgramacionReactivaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		ejemploMiObservable();
	}
	
	public void ejemploMiObservable() {
		Flux.create(emitter -> {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				private Integer contador = 0;
				
				@Override
				public void run() {
					emitter.next(++contador);
					
					if (contador == 10) {
						timer.cancel();
						emitter.complete();
					}
					
					if (contador == 5) {
						timer.cancel();
						emitter.error(new InterruptedException("Error, se ha detenido el flux en 5"));
					}
					
				}
			}, 1000, 1000);
		}).subscribe(
				next -> log.info(next.toString()), 
				error -> log.error(error.getMessage()), 
				() -> log.info("Final de proceso"));
	}

	public void ejemploBackpressure() {
		Flux.range(1, 10)
			.log()
			//.limitRate(5)
			.subscribe(new Subscriber<Integer>() {

			private Subscription s;

			private Integer limite = 5;
			private Integer consumido = 0;

			@Override
			public void onSubscribe(Subscription s) {
				// TODO Auto-generated method stub
				this.s = s;
				s.request(limite);
			}

			@Override
			public void onNext(Integer t) {
				// TODO Auto-generated method stub
				log.info(t.toString());
				consumido++;
				if (consumido == limite) {
					consumido = 0;
					s.request(limite);
				}
			}

			@Override
			public void onError(Throwable t) {
				// TODO Auto-generated method stub
				log.error(t.getMessage());
			}

			@Override
			public void onComplete() {
				// TODO Auto-generated method stub
				System.out.println("Proceso terminado");
			}

		});
	}

	public void ejemploBloqueoInterval() {

//		Flux<Integer> rango = Flux.range(1,12);
//		Flux<Long> retraso = Flux.interval(Duration.ofSeconds(1));
//		
//		rango.zipWith(retraso, (ra,re) -> ra)
//			.doOnNext(i -> log.info(i.toString()))
//			// El retraso hace que no le de tiempo a mostrar ningun elemento del rango.
//			// Elo hilo principal termina antes
//			.subscribe();
//			// SOLUCION -> bloquear el hilo principal hasta que termine el flujo rango
//			//.blockLast();

//		try {
//			Thread.sleep(13000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		Flux<Integer> rango = Flux.range(1, 12);
		Flux<Long> retraso = Flux.interval(Duration.ofSeconds(1));
		rango.zipWith(retraso, (ra, re) -> ra).doOnNext(i -> log.info(i.toString())).subscribe();

		// Otro ejemplo
//		Flux<Integer> rango2 = Flux.range(1,12)
//				.delayElements(Duration.ofSeconds(1))
//				.doOnNext(i -> log.info(i.toString()));
//		
//		rango2.blockLast();

	}

	public void ejemploRange() {
		Flux.just(1, 2, 3, 4).map(i -> i * 2)
				.zipWith(Flux.range(0, 4), (uno, dos) -> String.format("Primer flux: %d, Segundo flux: %d", uno, dos))
				.subscribe(texto -> log.info(texto));
	}

	public void ejemploCombinarFlujoszipWith() {
		// En vez de mostrar cada elemento de la lista, vamos a mostrar la lista
		// completa de una sola vez

		Mono<Usuario> usuarioMono = Mono.fromCallable(() -> new Usuario("Pepito", "Perez"));

		Mono<Comentarios> comentariosUsuarioMono = Mono.fromCallable(() -> {
			Comentarios comentarios = new Comentarios();
			comentarios.addComentario("Hoy es lunes");
			comentarios.addComentario("Hace mucho frio");
			comentarios.addComentario("Quiero que ya sea viernes");
			return comentarios;
		});

		Mono<UsuarioComentarios> usuarioComentarios = usuarioMono.zipWith(comentariosUsuarioMono,
				(usuario, comentariosUsuario) -> new UsuarioComentarios(usuario, comentariosUsuario));

		usuarioComentarios.subscribe(uc -> log.info(uc.toString()));
	}

	public void ejemploCombinarFlujosFlatMap() {
		// En vez de mostrar cada elemento de la lista, vamos a mostrar la lista
		// completa de una sola vez

		Mono<Usuario> usuarioMono = Mono.fromCallable(() -> new Usuario("Pepito", "Perez"));

		Mono<Comentarios> comentariosUsuarioMono = Mono.fromCallable(() -> {
			Comentarios comentarios = new Comentarios();
			comentarios.addComentario("Hoy es lunes");
			comentarios.addComentario("Hace mucho frio");
			comentarios.addComentario("Quiero que ya sea viernes");
			return comentarios;
		});

		usuarioMono.flatMap(u -> comentariosUsuarioMono.map(c -> new UsuarioComentarios(u, c)))
				.subscribe(uc -> log.info(uc.toString()));
	}

	public void ejemploFluxMono() {
		// En vez de mostrar cada elemento de la lista, vamos a mostrar la lista
		// completa de una sola vez

		List<Usuario> listaUsuarios = new ArrayList<>();
		listaUsuarios.add(new Usuario("Andres", "Perez"));
		listaUsuarios.add(new Usuario("Pedro", "Lopez"));
		listaUsuarios.add(new Usuario("Maria", "Arias"));
		listaUsuarios.add(new Usuario("Diego", "Sanchez"));
		listaUsuarios.add(new Usuario("Juan", "Rodriguez"));
		listaUsuarios.add(new Usuario("Maria", "Redondo"));

		// Muestra todos los usuarios uno a uno
		Flux.fromIterable(listaUsuarios).subscribe(usuario -> log.info(usuario.toString()));

		Flux.fromIterable(listaUsuarios)
				// Convierte a un mono, la lista de usuarios
				.collectList().subscribe(lista -> log.info(lista.toString()));

		Flux.fromIterable(listaUsuarios)
				// Convierte a un mono, la lista de usuarios
				.collectList().subscribe(lista -> {
					lista.forEach(item -> log.info(item.toString()));
				});
	}

	public void ejemploListaString() {

		List<Usuario> listaUsuarios = new ArrayList<>();
		listaUsuarios.add(new Usuario("Andres", "Perez"));
		listaUsuarios.add(new Usuario("Pedro", "Lopez"));
		listaUsuarios.add(new Usuario("Maria", "Arias"));
		listaUsuarios.add(new Usuario("Diego", "Sanchez"));
		listaUsuarios.add(new Usuario("Juan", "Rodriguez"));
		listaUsuarios.add(new Usuario("Maria", "Redondo"));

		Flux.fromIterable(listaUsuarios).map(
				usuario -> usuario.getNombre().toUpperCase().concat(" ").concat(usuario.getApellido().toUpperCase()))
				.flatMap(nombre -> {
					if (nombre.contains("maria".toUpperCase())) {
						return Mono.just(nombre);
					} else {
						return Mono.empty();
					}
				}).map(nombre -> {
					return nombre.toLowerCase();
				}).subscribe(e -> log.info(e.toString()));
	}

	public void ejemploFlatMap() {

		List<String> listaUsuarios = new ArrayList<>();
		listaUsuarios.add("Andres");
		listaUsuarios.add("Pedro");
		listaUsuarios.add("Maria");
		listaUsuarios.add("Diego");
		listaUsuarios.add("Juan");

		Flux.fromIterable(listaUsuarios).map(nombre -> new Usuario(nombre.toUpperCase(), null)).flatMap(usuario -> {
			if (usuario.getNombre().equalsIgnoreCase("maria")) {
				return Mono.just(usuario);
			} else {
				return Mono.empty();
			}
		}).map(usuario -> {
			String nombre = usuario.getNombre().toLowerCase();
			usuario.setNombre(nombre);
			return usuario;
		}).subscribe(e -> log.info(e.toString()));
	}

	public void ejemploObservableLista() {

		List<String> nombresUsuarios = new ArrayList<>();
		nombresUsuarios.add("Andres");
		nombresUsuarios.add("Pedro");
		nombresUsuarios.add("Maria");
		nombresUsuarios.add("Diego");
		nombresUsuarios.add("Juan");

		Flux<String> nombres = Flux.fromIterable(nombresUsuarios);

		Flux<Usuario> usuarios = nombres.map(nombre -> new Usuario(nombre.toUpperCase(), null))
				// .filter(usuario -> usuario.getNombre().equalsIgnoreCase("MARIA"))
				.doOnNext(usuario -> {
					if (usuario == null) {
						throw new RuntimeException("Nombre no puede ser vacio");
					}
					System.out.println(usuario);
				}).map(usuario -> {
					String nombre = usuario.getNombre().toLowerCase();
					usuario.setNombre(nombre);
					return usuario;
				});

		// Si me subscribo a nombres mostrara todos los nombres
		// Si me subscribo a usuarios solo mostrara maria en minisculas
		usuarios.subscribe(e -> log.info(e.toString()), error -> log.error(error.getMessage()), new Runnable() {

			@Override
			public void run() {
				log.info("Ha finalizado la ejecucion del observable");

			}
		});
	}

	public void ejemploInmutable() {
		Flux<String> nombres = Flux.just("Andres", "Pedro", "Maria", "Diego", "Juan");

		Flux<Usuario> usuarios = nombres.map(nombre -> new Usuario(nombre.toUpperCase(), null))
				.filter(usuario -> usuario.getNombre().equalsIgnoreCase("MARIA")).doOnNext(usuario -> {
					if (usuario == null) {
						throw new RuntimeException("Nombre no puede ser vacio");
					}
					System.out.println(usuario);
				}).map(usuario -> {
					String nombre = usuario.getNombre().toLowerCase();
					usuario.setNombre(nombre);
					return usuario;
				});

		// Si me subscribo a nombres mostrara todos los nombres
		// Si me subscribo a usuarios solo mostrara maria en minisculas
		usuarios.subscribe(e -> log.info(e.toString()), error -> log.error(error.getMessage()), new Runnable() {

			@Override
			public void run() {
				log.info("Ha finalizado la ejecucion del observable");

			}
		});
	}

	public void ejemploFilter() {
		Flux<Usuario> nombres = Flux.just("Andres", "Pedro", "Maria", "Diego", "Juan")
				.map(nombre -> new Usuario(nombre.toUpperCase(), null))
				.filter(usuario -> usuario.getNombre().equalsIgnoreCase("MARIA")).doOnNext(usuario -> {
					if (usuario == null) {
						throw new RuntimeException("Nombre no puede ser vacio");
					}
					System.out.println(usuario);
				}).map(usuario -> {
					String nombre = usuario.getNombre().toLowerCase();
					usuario.setNombre(nombre);
					return usuario;
				});

		nombres.subscribe(e -> log.info(e.toString()), error -> log.error(error.getMessage()), new Runnable() {

			@Override
			public void run() {
				log.info("Ha finalizado la ejecucion del observable");

			}
		});
	}

	public void ejemploMap() {
		Flux<Usuario> nombres = Flux.just("Andres", "Pedro", "Maria", "Diego", "Juan")
				.map(nombre -> new Usuario(nombre.toUpperCase(), null)).doOnNext(usuario -> {
					if (usuario == null) {
						throw new RuntimeException("Nombre no puede ser vacio");
					}
					System.out.println(usuario);
				}).map(usuario -> {
					String nombre = usuario.getNombre().toLowerCase();
					usuario.setNombre(nombre);
					return usuario;
				});

		nombres.subscribe(e -> log.info(e.toString()), error -> log.error(error.getMessage()), new Runnable() {

			@Override
			public void run() {
				log.info("Ha finalizado la ejecucion del observable");

			}
		});
	}

	public void ejemploOnComplete() {
		Flux<String> nombres = Flux.just("Andres", "Pedro", "Maria", "Diego", "Juan").doOnNext(e -> {
			if (e.isEmpty()) {
				throw new RuntimeException("Nombre no puede ser vacio");
			}
			System.out.println(e);
		});

		nombres.subscribe(e -> log.info(e), error -> log.error(error.getMessage()), new Runnable() {

			@Override
			public void run() {
				log.info("Ha finalizado la ejecucion del observable");

			}
		});
	}

	public void ejemploVacio() {
		// Controlar que los nombres no vengan vacios
		Flux<String> nombres = Flux.just("Andres", "Pedro", "", "Diego", "Juan").doOnNext(e -> {
			if (e.isEmpty()) {
				throw new RuntimeException("Nombre no puede ser vacio");
			}
			System.out.println(e);
		});

		nombres.subscribe(e -> log.info(e), error -> log.error(error.getMessage()));

	}

	public void ejemploCrearFlujo() {

//		 Crear un flujo
//				 Segun vamos recibiendo los datos los procesamos
//		Flux<String> nombres = Flux.just("Andres", "Pedro", "Diego", "Juan")
//				.doOnNext(elemento -> System.out.println(elemento));

		Flux<String> nombres = Flux.just("Andres", "Pedro", "Diego", "Juan").doOnNext(System.out::println);

		nombres.subscribe();
	}

}
