package com.viewnext.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.documents.Producto;
import com.viewnext.services.ProductoService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/productos")
public class ProductoRestController {
	
private static final Logger log = LoggerFactory.getLogger(ProductoRestController.class);
	
	@Autowired
	private ProductoService service;
	
	@GetMapping
	public Flux<Producto> index() {
		Flux<Producto> productos = service.findAll()
				.map(producto -> {
					producto.setDescripcion(producto.getDescripcion().toUpperCase());
					return producto;
				}).doOnNext(prod -> log.info(prod.getDescripcion()));
		
		return productos;
	}
	
	@GetMapping("/{id}")
	public Mono<Producto> buscar(@PathVariable String id) {
		// Buscar por id y devolver un Mono
		Mono<Producto> producto = service.findById(id);
		
		// Recorro todos los productos y filtro por id. El resultado lo tranformamos a Mono
		
		return producto;
	}
	
	@GetMapping("/eliminar/{id}")
	public Mono<String> eliminar(@PathVariable String id){
		
		// Buscar el producto y despues borrarlo
		return service.findById(id)
				.defaultIfEmpty(new Producto())
				.flatMap(p -> {
					if (p.getId() == null) {
						return Mono.error(new InterruptedException("El producto no existe"));
					}
					return Mono.just(p);
				})
				.flatMap(p -> {
					log.info("Eliminando el producto " + p.getDescripcion());
					return service.delete(p);
					})
				.then(Mono.just("redirect:/listar?success=producto+eliminado"))
				.doOnError(ex -> Mono.just("redirect:/listar?error=no+existe+el+producto"));
				
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
