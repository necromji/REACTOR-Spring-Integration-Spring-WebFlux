package com.viewnext.controllers;

import java.time.Duration;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.thymeleaf.spring5.context.webflux.ReactiveDataDriverContextVariable;

import com.viewnext.dao.ProductoDao;
import com.viewnext.documents.Producto;
import com.viewnext.services.ProductoService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Controller
public class ProductoController {
	
	private static final Logger log = LoggerFactory.getLogger(ProductoController.class);
	
	@Autowired
	private ProductoDao dao;
	
	@Autowired
	private ProductoService service;
	
	@GetMapping("/form")
	public Mono<String> mostrarFormulario(Model model) {
		model.addAttribute("producto", new Producto());
		model.addAttribute("titulo", "Formulario de producto");
		model.addAttribute("boton", "Alta");
		return Mono.just("form");
	}
	
	@PostMapping("/form")
	public Mono<String> insertar(@Valid Producto producto, BindingResult result, Model model){
		
		if (result.hasErrors()) {
			model.addAttribute("mensaje", "Hay errores en el formulario");
			return Mono.just("form");
		}
		
		return service.save(producto)
				.doOnNext(p -> {
					log.info("Producto insertado correctamente");
				}).thenReturn("redirect:/listar?success=producto+insertado+correctamente");
	}
	
	@GetMapping("/form/{id}")
	public Mono<String> editar(@PathVariable String id, Model model){
		
		// Buscar el producto y enviarlo al formulario
		Mono<Producto> productoMono = service.findById(id)
				.doOnNext(p -> {
					log.info("Producto: " + p.getDescripcion());
				})
				.defaultIfEmpty(new Producto());
		
		model.addAttribute("producto", productoMono);
		model.addAttribute("boton", "Actualizar");
		model.addAttribute("titulo", "Editar producto");
		
		return Mono.just("form");
	}

	@GetMapping("/eliminar/{id}")
	public Mono<String> eliminar(@PathVariable String id){
		
		// Buscar el producto y despues borrarlo
		return service.findById(id)
				.defaultIfEmpty(new Producto())
				.flatMap(p -> {
					if (p.getId() == null) {
						return Mono.error(new InterruptedException("El producto no existe"));
					}
					return Mono.just(p);
				})
				.flatMap(p -> {
					log.info("Eliminando el producto " + p.getDescripcion());
					return service.delete(p);
					})
				.then(Mono.just("redirect:/listar?success=producto+eliminado"))
				.doOnError(ex -> Mono.just("redirect:/listar?error=no+existe+el+producto"));		
		
	}
	
	
//	@RequestMapping(method = RequestMethod.GET, path = "")
	@GetMapping({"/listar","/"})
	public String listar(Model model) {
		Flux<Producto> productos = dao.findAll()
				.map(producto -> {
					producto.setDescripcion(producto.getDescripcion().toUpperCase());
					return producto;
				});
		
		productos.subscribe(prod -> log.info(prod.getDescripcion()));
		
		model.addAttribute("productos", productos);
		model.addAttribute("titulo", "Listado de productos");
		
		// Devuelve el nombre de la vista que mostrara los datos
		return "listar";
	}
	
	@GetMapping("/listar-datadriver")
	public String listarDataDriver(Model model) {
		Flux<Producto> productos = dao.findAll()
				.map(producto -> {
					producto.setDescripcion(producto.getDescripcion().toUpperCase());
					return producto;
				}). delayElements(Duration.ofSeconds(1));
		
		productos.subscribe(prod -> log.info(prod.getDescripcion()));
		
		// Limitando por numero de documentos
		model.addAttribute("productos", new ReactiveDataDriverContextVariable(productos, 2));
		model.addAttribute("titulo", "Listado de productos");
		
		// Devuelve el nombre de la vista que mostrara los datos
		return "listar";
	}
	
	@GetMapping("/listar-full")
	public String listarFull(Model model) {
		Flux<Producto> productos = dao.findAll()
				.map(producto -> {
					producto.setDescripcion(producto.getDescripcion().toUpperCase());
					return producto;})
				. delayElements(Duration.ofMillis(200))
				.repeat(5000);
		
		productos.subscribe(prod -> log.info(prod.getDescripcion()));
		
		// Limitando por el tamaño del buffer definido en application.properties
		model.addAttribute("productos", new ReactiveDataDriverContextVariable(productos));
		model.addAttribute("titulo", "Listado de productos");
		
		// Devuelve el nombre de la vista que mostrara los datos
		return "listar-chuncked";
	}
}
