package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;

import com.viewnext.dao.ProductoDao;
import com.viewnext.documents.Producto;

import reactor.core.publisher.Flux;

@SpringBootApplication
public class Ejemplo8MongoDbApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDao dao;
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo8MongoDbApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Cada vez que arranco la aplicacion borro todos los registros anteriores
		mongoTemplate.dropCollection("productos").subscribe();
		
		Flux.just(new Producto("Pizarra", 129), new Producto("Portatil", 799))
			.flatMap(producto ->  dao.save(producto))
			.subscribe(producto -> System.out.println(producto));
		
	}

}
