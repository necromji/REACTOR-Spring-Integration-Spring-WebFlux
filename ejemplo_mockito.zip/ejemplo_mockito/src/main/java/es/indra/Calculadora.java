package es.indra;

public interface Calculadora {
	
	int sumar();

}
