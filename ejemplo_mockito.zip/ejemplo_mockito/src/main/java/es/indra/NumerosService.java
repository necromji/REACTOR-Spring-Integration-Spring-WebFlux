package es.indra;

public interface NumerosService {
	
	int[] getNumeros();

}
