package es.indra;

public class NumerosServiceImpl implements NumerosService {

	public int[] getNumeros() {
		int [] numeros = {7,1,4,9,3};
		return numeros;
	}

}
