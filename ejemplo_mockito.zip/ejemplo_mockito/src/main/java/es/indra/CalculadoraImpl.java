package es.indra;

public class CalculadoraImpl implements Calculadora{
	
	private NumerosService numerosService;

	public int sumar() {
		int suma = 0;
		int [] numeros = numerosService.getNumeros();
		
		for (int i : numeros) {
			suma += i;
		}
		
		return suma;
	}
	
	public void setNumerosService(NumerosService numerosService) {
		this.numerosService = numerosService;
	}

}
