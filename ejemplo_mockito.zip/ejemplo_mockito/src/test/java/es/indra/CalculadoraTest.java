package es.indra;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CalculadoraTest {
	
	@InjectMocks
	private CalculadoraImpl calculadoraImpl;
	
	@InjectMocks
	private NumerosServiceImpl numerosServiceImpl;
	
	@Test
	public void testSumar() {
		calculadoraImpl.setNumerosService(numerosServiceImpl);
		assertEquals(24, calculadoraImpl.sumar());
	}

}
