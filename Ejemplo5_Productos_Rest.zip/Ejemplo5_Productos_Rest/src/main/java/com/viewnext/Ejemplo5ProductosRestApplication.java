package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo5ProductosRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5ProductosRestApplication.class, args);
	}

}
