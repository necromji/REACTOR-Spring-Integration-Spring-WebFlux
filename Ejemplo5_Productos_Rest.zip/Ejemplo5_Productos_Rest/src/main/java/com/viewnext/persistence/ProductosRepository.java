package com.viewnext.persistence;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductosRepository extends PagingAndSortingRepository<Producto,Integer> {
	
	// El nombre del metodo findBy + nombre de la propiedad
	List<Producto> findByDescripcion(@Param("descripcion") String descripcion);

}
