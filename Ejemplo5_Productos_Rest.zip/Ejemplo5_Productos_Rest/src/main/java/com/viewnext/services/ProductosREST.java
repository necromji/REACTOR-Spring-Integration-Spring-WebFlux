package com.viewnext.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.persistence.Producto;
import com.viewnext.persistence.ProductosRepository;

@RestController
@RequestMapping("/productosWS")
public class ProductosREST {
	
	@Autowired
	private ProductosRepository productosRepository;
	
	// http://localhost:9090/productosWS?codigo=1
	@GetMapping
	public Producto buscarPorID(@RequestParam(value = "codigo") int id) {
		System.out.println(productosRepository.findById(id).get());
		return productosRepository.findById(id).get();
	}
	
	@PostMapping
	public void alta(Producto nuevo) {
		
	}
	
	@DeleteMapping
	public void eliminar(@RequestParam(value = "codigo") int id) {
		
	}
	
	@PutMapping
	public void modificar(Producto modificado) {
		
	}

}
