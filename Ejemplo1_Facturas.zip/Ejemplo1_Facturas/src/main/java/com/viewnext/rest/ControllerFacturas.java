package com.viewnext.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.models.Factura;

@RestController
public class ControllerFacturas {
	
	@GetMapping("/facturas")
	public List<Factura> getFacturas(){
		List<Factura> facturas = new ArrayList<Factura>();
		
		for(int i=1; i<=10; i++){
			facturas.add(new Factura(i, "Factura " + i, i*100));
		}
		
		try {
			Thread.sleep(4000);
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return facturas;
	}

}
