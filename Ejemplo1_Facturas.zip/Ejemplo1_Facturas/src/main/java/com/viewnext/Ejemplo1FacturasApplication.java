package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo1FacturasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo1FacturasApplication.class, args);
	}

}
