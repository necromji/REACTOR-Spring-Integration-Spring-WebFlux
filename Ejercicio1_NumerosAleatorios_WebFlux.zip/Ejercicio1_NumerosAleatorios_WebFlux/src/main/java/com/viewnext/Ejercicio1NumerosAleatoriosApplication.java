package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio1NumerosAleatoriosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio1NumerosAleatoriosApplication.class, args);
	}

}
