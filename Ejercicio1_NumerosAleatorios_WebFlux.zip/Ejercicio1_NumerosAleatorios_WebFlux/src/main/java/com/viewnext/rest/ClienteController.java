package com.viewnext.rest;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Flux;

@Controller
public class ClienteController {
	
	@RequestMapping("/mostrar")
	public String mostrarNumeros() {
		
		long inicio = System.currentTimeMillis();
		
		List<Integer> todosNumeros = solicitarNumeros().collectList().block();
		
		System.out.println(todosNumeros);
		
		long fin = System.currentTimeMillis();
		System.out.println("Tiempo transcurrido: " + (fin-inicio) + "mseg.");
		
		return "vista";
	}
	
	private Flux<Integer> solicitarNumeros(){
		WebClient cliente = WebClient.create("http://localhost:9091/numeros");
		Flux<Integer> nums1 = cliente.get().retrieve().bodyToFlux(Integer.class);
		Flux<Integer> nums2 = cliente.get().retrieve().bodyToFlux(Integer.class);
		Flux<Integer> nums3 = cliente.get().retrieve().bodyToFlux(Integer.class);
		Flux<Integer> nums4 = cliente.get().retrieve().bodyToFlux(Integer.class);
		Flux<Integer> nums5 = cliente.get().retrieve().bodyToFlux(Integer.class);
		Flux<Integer> todas = Flux.merge(nums1, nums2, nums3, nums4, nums5);
		return todas;
	}

}
