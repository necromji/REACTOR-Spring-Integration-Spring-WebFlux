package com.viewnext.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.viewnext.models.Factura;
import com.viewnext.services.ServiceClienteFacturas;

@Controller
public class FacturasRest {
	
	@Autowired
	private ServiceClienteFacturas serviceClienteFacturas;
	
	@RequestMapping("/todas")
	public String todasFacturas(Model modelo) {
		
		long inicio = System.nanoTime();
		List<Factura> lista = new ArrayList<>();
		lista.addAll(serviceClienteFacturas.getAll());
		lista.addAll(serviceClienteFacturas.getAll());
		lista.addAll(serviceClienteFacturas.getAll());
		lista.addAll(serviceClienteFacturas.getAll());
		
		long fin = System.nanoTime();
		System.out.println("Tiempo :: " + (fin-inicio) + "nanoSeg.");
		
		modelo.addAttribute("lista", lista);
		return "vista";
	}

}
