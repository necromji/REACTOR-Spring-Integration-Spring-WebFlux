package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo2ClienteFacturasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2ClienteFacturasApplication.class, args);
	}

}
