package com.viewnext.models;

public class Factura {
	
	private int numero;
	private String detalle;
	private double importe;
	
	public Factura() {
		// TODO Auto-generated constructor stub
	}

	public Factura(int numero, String detalle, double importe) {
		super();
		this.numero = numero;
		this.detalle = detalle;
		this.importe = importe;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	@Override
	public String toString() {
		return "Factura [numero=" + numero + ", detalle=" + detalle + ", importe=" + importe + "]";
	}
	
	

}
