package com.viewnext.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.viewnext.models.Factura;

@Service
public class ServiceClienteFacturas {
	
	public List<Factura> getAll(){
		RestTemplate template = new RestTemplate();
		Factura[] facturas = template.getForObject("http://localhost:8081/facturas", Factura[].class);
		List<Factura> lista = Arrays.asList(facturas);
		return lista;
	}

}
