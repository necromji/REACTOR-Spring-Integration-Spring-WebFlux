package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;

import com.viewnext.dao.CategoriaDao;
import com.viewnext.dao.ProductoDao;
import com.viewnext.documents.Categoria;
import com.viewnext.documents.Producto;

import reactor.core.publisher.Flux;

@SpringBootApplication
public class Ejemplo9MongoDbApiRestApplication implements CommandLineRunner{

	
	@Autowired
	private ProductoDao daoProducto;
	
	@Autowired
	private CategoriaDao daoCategoria;
	
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo9MongoDbApiRestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Cada vez que arranco la aplicacion borro todos los registros anteriores
		mongoTemplate.dropCollection("productos").subscribe();
		mongoTemplate.dropCollection("categorias").subscribe();
		
		Categoria matOficina = new Categoria("Material oficina");
		Categoria electrico = new Categoria("Electrico");
		Categoria consumible = new Categoria("Consumible");
		
		Flux.just(matOficina, electrico, consumible)
			.flatMap(categoria -> daoCategoria.save(categoria))
			.doOnNext(categoria -> System.out.println(categoria))
			.thenMany(
					Flux.just(new Producto("Pizarra", 129, matOficina), 
							new Producto("Portatil", 799, electrico),
							new Producto("Mesa", 80, matOficina),
							new Producto("Silla", 47, matOficina),
							new Producto("Proyector", 230, electrico),
							new Producto("Lampara", 90, matOficina),
							new Producto("Papelera", 20, matOficina),
							new Producto("Bombillas", 15, consumible))
						.flatMap(producto ->  daoProducto.save(producto))
						
					).subscribe(producto -> System.out.println(producto));

	}
}
