package com.viewnext.controllers;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.documents.Producto;
import com.viewnext.services.ProductoService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/productos")
public class ProductoRestController {

	private static final Logger log = LoggerFactory.getLogger(ProductoRestController.class);

	@Autowired
	private ProductoService service;

	@GetMapping
	public Mono<ResponseEntity<Flux<Producto>>> lista() {

		return Mono.just(ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(service.findAll()));
	}

	@GetMapping("/{id}")
	public Mono<ResponseEntity<Producto>> buscar(@PathVariable String id) {

		return service.findById(id)
				.map(producto -> ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(producto))
				.defaultIfEmpty(ResponseEntity.notFound().build());

	}



	@PostMapping
	public Mono<ResponseEntity<Map<String,Object>>> crear(@RequestBody Mono<Producto> monoProducto){
		
		Map<String,Object> respuesta = new HashMap<String, Object>();
			
		return monoProducto.flatMap(producto -> {
				return service.findCategoriaByNombre(producto.getCategoria().getNombre())
					.flatMap(c -> {
							producto.setCategoria(c);
							return Mono.just(producto);
							})
					.flatMap(producto2 -> {
						return service.save(producto2)
						.map( p -> {
							respuesta.put("producto", p);
							respuesta.put("mensaje", "Producto insertado correctamente");
							return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(respuesta);
							});
						
					});
		});
	}

	@DeleteMapping("/{id}")
	public Mono<ResponseEntity<Void>> eliminar(@PathVariable String id){
		
		// Buscar el producto y despues borrarlo
		return service.findById(id)
				.flatMap(p -> {
					return service.delete(p)
				.then(Mono.just(new ResponseEntity<Void>(HttpStatus.OK)));
				})
				.defaultIfEmpty(new ResponseEntity<Void>(HttpStatus.NOT_FOUND));

	}

}
