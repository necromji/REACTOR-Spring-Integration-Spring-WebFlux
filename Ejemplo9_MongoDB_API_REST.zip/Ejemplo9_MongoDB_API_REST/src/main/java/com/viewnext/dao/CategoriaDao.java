package com.viewnext.dao;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.viewnext.documents.Categoria;

import reactor.core.publisher.Mono;

public interface CategoriaDao extends ReactiveMongoRepository<Categoria, String>{

	 public Mono<Categoria> findByNombre(String nombre);
}
