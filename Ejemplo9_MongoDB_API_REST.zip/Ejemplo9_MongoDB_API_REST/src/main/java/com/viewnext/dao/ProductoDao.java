package com.viewnext.dao;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.viewnext.documents.Producto;

public interface ProductoDao extends ReactiveMongoRepository<Producto, String>{

}
