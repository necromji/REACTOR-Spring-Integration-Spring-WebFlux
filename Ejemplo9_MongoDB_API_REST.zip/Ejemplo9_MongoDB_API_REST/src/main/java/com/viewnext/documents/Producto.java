package com.viewnext.documents;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "productos")
public class Producto {

	@Id
	private String id;

	@NotEmpty(message = "Te has liado .... no puede estar vacio")
	private String descripcion;

	@Min(value = 1, message = "Demasiado barato, precio minimo 1€")
	private double precio;

	private Categoria categoria;

	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(@NotEmpty(message = "Te has liado .... no puede estar vacio") String descripcion,
			@Min(value = 1, message = "Demasiado barato, precio minimo 1€") double precio, Categoria categoria) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
		this.categoria = categoria;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + ", categoria=" + categoria
				+ "]";
	}

}
