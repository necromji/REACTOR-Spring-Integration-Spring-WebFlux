package com.viewnext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public class TestLambdas {

	public static void main(String[] args) {
		
		List<Alumno> listaAlumnos = new ArrayList<>();
		listaAlumnos.add(new Alumno(1, "Juan", "Lopez", "Spring", 8.3));
		listaAlumnos.add(new Alumno(2, "Maria", "Sanz", "JPA", 5.8));
		listaAlumnos.add(new Alumno(3, "Luis", "Arias", "Spring", 4.1));
		listaAlumnos.add(new Alumno(4, "Jorge", "Rodriguez", "Hibernate", 7.2));
		listaAlumnos.add(new Alumno(5, "Antonio", "Martinez", "JPA", 9.6));
		listaAlumnos.add(new Alumno(6, "Mercedes", "Nuñez", "Spring", 3.2));
		
		// Mostrar todos los alumnos
//		for (Alumno alumno : listaAlumnos) {
//			System.out.println(alumno);
//		}
		
		listaAlumnos.stream().forEach((alumno) -> System.out.println(alumno));
		System.out.println("--------------------");
		listaAlumnos.stream().forEach(System.out::println);
		System.out.println("--------------------");
		
		// El peor alumno (menor nota)
		System.out.println(
				listaAlumnos.stream().min((alum1, alum2) -> (int)(alum1.getNota()) - (int)(alum2.getNota())));
		System.out.println("--------------------");
		
		System.out.println(listaAlumnos.stream().mapToDouble(i -> i.getNota()).min().getAsDouble());
		System.out.println("--------------------");
		
		
		// Buscar los alumnos cuyo nombre comienza por la letra M
		listaAlumnos.stream().filter(a -> a.getNombre().charAt(0) == 'M').forEach(a -> System.out.println(a));
		System.out.println("--------------------");
		
		
		// Mostrar el numero de alumnos en la lista
		System.out.println(listaAlumnos.stream().count());
		System.out.println("--------------------");
		
		
		// Buscar los alumnos cuyo apellido termine con z
		listaAlumnos.stream().filter(a -> a.getApellido().endsWith("z")).forEach(System.out::println);
		System.out.println("--------------------");
		
		
		// Los dos alumnos con mejor nota
		//System.out.println(listaAlumnos.stream().limit(2).max((alum1, alum2) -> (int)(alum1.getNota()) - (int)(alum2.getNota())));
		listaAlumnos.stream().sorted(Comparator.comparing(Alumno::getNota).reversed()).limit(2).forEach(System.out::println);
		System.out.println("--------------------");
		
		// Los alumnos cuyo nombre tiene mas de 4 letras y estan aprobados 
		Predicate<Alumno> nombre = a -> a.getNombre().length() > 4;
		Predicate<Alumno> aprobados = a -> a.getNota() >= 5;
		listaAlumnos.stream().filter(nombre.and(aprobados)).forEach(System.out::println);
		

	}

}
