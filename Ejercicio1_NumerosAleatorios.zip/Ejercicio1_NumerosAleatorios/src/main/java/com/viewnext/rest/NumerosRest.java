package com.viewnext.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NumerosRest {

	@GetMapping("/numeros")
	public List<Integer> getNumeros(){
		
		List<Integer> lista = new ArrayList<Integer>();
		
		for(int i=1; i<=5; i++) {
			lista.add((int)(Math.random()*100));
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return lista;
	}
}
