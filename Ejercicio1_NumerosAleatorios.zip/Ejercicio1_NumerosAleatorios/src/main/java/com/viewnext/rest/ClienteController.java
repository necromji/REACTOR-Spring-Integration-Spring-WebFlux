package com.viewnext.rest;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class ClienteController {
	
	@RequestMapping("/mostrar")
	public String mostrarNumeros() {
		
		long inicio = System.currentTimeMillis();
		
		List<Integer> todos = new ArrayList<>();
		
		for(int i=1; i<=5; i++) {
			RestTemplate template = new RestTemplate();
			List<Integer> lista = template.getForObject("http://localhost:9090/numeros", List.class);	
			todos.addAll(lista);
		}
		
		System.out.println(todos);
		
		long fin = System.currentTimeMillis();
		System.out.println("Tiempo transcurrido: " + (fin-inicio) + "mseg.");
		
		return "vista";
	}

}
