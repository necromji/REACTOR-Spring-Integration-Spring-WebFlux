package com.viewnext.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnosServices {
	
	public Mono<ServerResponse> getAll(ServerRequest request){
		
		List<Alumno> lista = new ArrayList<>();
		lista.add(new Alumno(1, "Juan", "Lopez", 5.6));
		lista.add(new Alumno(2, "Maria", "Sanz", 8.4));
		lista.add(new Alumno(3, "Laura", "Arias", 6.3));
		lista.add(new Alumno(4, "Antonio", "Rodriguez", 7.2));
		
		Flux<Alumno> alumnos = Flux.fromIterable(lista); 
		return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(alumnos, Alumno.class);
	}

}
