package com.viewnext.services;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.reactive.function.server.RouterFunction;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;


@Configuration
@EnableWebFlux
@CrossOrigin
public class AlumnosRouter {
	
	@Bean
	public RouterFunction publicarServicio(AlumnosServices alumnosServices){
		// Me invento la ruta donde publicar el servicio
		return route(GET("sw/alumno").and(accept(MediaType.APPLICATION_JSON)), alumnosServices::getAll);
	}

}
