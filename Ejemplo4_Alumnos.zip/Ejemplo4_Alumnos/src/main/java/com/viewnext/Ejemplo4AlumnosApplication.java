package com.viewnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo4AlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4AlumnosApplication.class, args);
	}

}
